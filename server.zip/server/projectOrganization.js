const __projectStructure = [
	// 0
'index.js',
	// 1
'projectOrganization.js',
	// 2
'routedefinitions.js',
	// 3
'users.controller.js',
	// 4
'user.js'
// 5
];
module.exports = { __projectStructure };
