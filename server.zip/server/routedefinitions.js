const user = require('./routes/user.js');

module.exports = {
user
};